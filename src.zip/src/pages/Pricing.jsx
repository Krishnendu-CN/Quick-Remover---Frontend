import React from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { Container, Typography } from "@mui/material";

export default function About() {
  return (
    <>
      <Header />
      <Container sx={{ py: 5 }}>
        <Typography variant="h3" align="center">About Us</Typography>
        <Typography variant="body1" align="center" sx={{ mt: 2 }}>
          This is an example about page.
        </Typography>
      </Container>
      <Footer />
    </>
  );
}
