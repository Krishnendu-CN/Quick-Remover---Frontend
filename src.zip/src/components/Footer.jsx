import React from "react";
import { Box, Typography, TextField, Button, Grid } from "@mui/material";

export default function Footer() {
  return (
    <Box sx={{ bgcolor: "grey.900", color: "grey.300", py: 8, px: 2 }}>
      <Grid container maxWidth="lg" spacing={4} mx="auto">
        <Grid item xs={12} md={4}>
          <Typography variant="h6" sx={{ color: "white", mb: 2, fontWeight: 'bold' }}>
            Blog
          </Typography>
          <Box component="ul" sx={{ listStyle: "none", p: 0, m: 0 }}>
            <li>New AI updates</li>
            <li>Background tips</li>
          </Box>
        </Grid>

        <Grid item xs={12} md={4}>
          <Typography variant="h6" sx={{ color: "white", mb: 2, fontWeight: 'bold' }}>
            Get Updates
          </Typography>
          <TextField
            placeholder="Enter your email"
            variant="outlined"
            size="small"
            fullWidth
            sx={{ mb: 1, bgcolor: "white", borderRadius: 1 }}
          />
          <Button variant="contained" color="primary" fullWidth>
            Subscribe
          </Button>
        </Grid>

        <Grid item xs={12} md={4}>
          <Typography variant="h6" sx={{ color: "white", mb: 2, fontWeight: 'bold' }}>
            Links
          </Typography>
          <Box component="ul" sx={{ listStyle: "none", p: 0, m: 0 }}>
            <li>Pricing</li>
            <li>API</li>
            <li>Contact</li>
          </Box>
        </Grid>
      </Grid>

      <Typography sx={{ textAlign: "center", mt: 4, fontSize: "0.875rem", color: "grey.500" }}>
        © {new Date().getFullYear()} remove.bg Clone – All rights reserved.
      </Typography>
    </Box>
  );
}
