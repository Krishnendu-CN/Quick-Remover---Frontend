import React, { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import {
  Box,
  Button,
  Container,
  Typography,
  Card,
  CardContent,
  Grid,
  Tabs,
  Tab,
  useMediaQuery,
  useTheme
} from "@mui/material";
import ReactCompareImage from "react-compare-image";
import Header from "../components/Header";
import Footer from "../components/Footer";

export default function Home() {
  const navigate = useNavigate();
  const [dragOver, setDragOver] = useState(false);
  const [tabValue, setTabValue] = useState(0);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));

  const handleFile = (file) => {
    if (file) {
      const previewUrl = URL.createObjectURL(file);
      navigate("/upload", { state: { file, preview: previewUrl } });
    }
  };

  const handleFileChange = (e) => handleFile(e.target.files[0]);
  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    handleFile(e.dataTransfer.files[0]);
  };
  //const [tabValue, setTabValue] = useState(0);
const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const videos = [
    {
      poster: "https://sb.kaleidousercontent.com/67418/840x560/686381d375/emilia-poster.jpg",
      src: "https://sb.kaleidousercontent.com/67418/x/681f13b37d/emilia_compressed.mp4",
    },
    {
      poster: "https://sb.kaleidousercontent.com/67418/840x560/d749ed76de/manuel-poster.jpg",
      src: "https://sb.kaleidousercontent.com/67418/x/9289c7b8dd/manuel_compressed.mp4",
    },
  ];

  const selectedVideo = useMemo(
    () => videos[Math.floor(Math.random() * videos.length)],
    []
  );

  const imagePairs = [
    {
      before: "https://sb.kaleidousercontent.com/67418/992x558/b9305ff4cd/stunning-quality-animal.png",
      after: "https://sb.kaleidousercontent.com/67418/992x558/84082a6eda/stunning-quality-animal-transp.png",
      title: "Animals"
    },
    {
      before: "https://sb.kaleidousercontent.com/67418/992x558/b024f7a4e1/stunning-quality-product.png",
      after: "https://sb.kaleidousercontent.com/67418/992x558/235d7eafc9/stunning-quality-prodcut-transp.png",
      title: "Products"
    },
    {
      before: "https://sb.kaleidousercontent.com/67418/992x558/ef4cc24685/people-org.png",
      after: "https://sb.kaleidousercontent.com/67418/992x558/7632960ff9/people.png",
      title: "People"
    }
  ];

  const imagePairsnew = [
    {
      before: "../animal-1.png",
      after: "../animal-2.png",
      title: "Animals"
    },
    {
      before: "../prodcut-2.jpg",
      after: "../product-2.png",
      title: "Products"
    },
    {
      before: "../person-1.png",
      after: "../person-2.png",
      title: "People"
    }
  ];

  return (
    <>
      <Header />
      <Container maxWidth="lg" sx={{ py: 8 }}>
        <Grid container spacing={6} alignItems="center">
          {/* Left Section */}
          <Grid item xs={12} md={6}>
            <Box sx={{ display: "flex", flexDirection: "column", alignItems: { xs: "center", md: "flex-start" }, gap: 3 }}>
              <Box
                component="video"
                preload="auto"
                autoPlay
                playsInline
                muted
                loop
                poster={selectedVideo.poster}
                src={selectedVideo.src}
                sx={{
                  width: "100%",
                  maxWidth: { xs: 320, lg: 420 },
                  borderRadius: "24px",
                  boxShadow: 3,
                }}
              />
              <Typography variant="h3" fontWeight="bold" sx={{ fontSize: "50px", lineHeight: 1.2 }}>
                Remove Image Background
              </Typography>
              <Typography variant="h5" color="text.secondary" sx={{ maxWidth: 420 }} paragraph>
                100% Automatically and{" "}
                <Box component="span" sx={{ color: "#f9a825", fontWeight: 700 }}>
                  Free
                </Box>
              </Typography>
            </Box>
          </Grid>

          {/* Right Section (Upload) */}
          <Grid item xs={12} md={6}>
            <Card sx={{ textAlign: "center", borderRadius: 11, boxShadow: 3 }}>
              <CardContent>
                <Box
                  onDragOver={(e) => {
                    e.preventDefault();
                    setDragOver(true);
                  }}
                  onDragLeave={() => setDragOver(false)}
                  onDrop={handleDrop}
                  sx={{
                    borderRadius: 11,
                    p: 10,
                    cursor: "pointer",
                    backgroundColor: dragOver ? "rgba(0,0,0,0.05)" : "transparent",
                    transition: "background-color 0.2s ease"
                  }}
                  onClick={() => document.getElementById("fileInput").click()}
                >
                  <Typography variant="h6" gutterBottom>Upload Image</Typography>
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    or drop a file, paste image or URL
                  </Typography>

                  <Button variant="contained" component="label" sx={{ mt: 2 }}>
                    Upload
                    <input
                      id="fileInput"
                      type="file"
                      accept="image/*"
                      hidden
                      onChange={handleFileChange}
                    />
                  </Button>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        {/* Tabbed Before/After Comparison */}
        <Box sx={{ mt: 12, textAlign: "center" }}>
          <Typography variant="h3" fontWeight="bold" gutterBottom>
            Stunning Results
          </Typography>
          <Typography variant="h6" color="text.secondary" sx={{ mb: 4 }}>
            Switch tabs & slide to compare
          </Typography>

          <Tabs
            value={tabValue}
            onChange={(e, newValue) => setTabValue(newValue)}
            centered
            variant={isMobile ? "fullWidth" : "standard"}
            sx={{ mb: 4 }}
          >
            {imagePairs.map((pair, index) => (
              <Tab key={index} label={pair.title} />
            ))}
          </Tabs>

          {/* Show selected tab's slider */}
          <Box sx={{ maxWidth: 800, mx: "auto" }}>
            <ReactCompareImage
              leftImage={imagePairs[tabValue].before}
              rightImage={imagePairs[tabValue].after}
              sliderLineColor="#fff"
              sliderPositionPercentage={0.5}
            />
          </Box>
        </Box>

        
        <Box
      sx={{
        display: "flex",
        flexDirection: { xs: "column", md: "row" }, // Stack on mobile, side-by-side on desktop
        alignItems: "center",
        gap: 4, // spacing between columns
        py: 6,
      }}
    >
      {/* Left Side - Text */}
      <Box sx={{ flex: 1 }}>
        <Typography
          variant="h3"
          fontWeight="bold"
          sx={{ fontSize: { xs: "2rem", md: "2.5rem" }, lineHeight: 1.3, mb: 2 }}
        >
          Background remover: Fully automated in 5 seconds with 1 click
        </Typography>

        <Typography variant="body1" color="text.secondary" sx={{ lineHeight: 1.7, mb: 2 }}>
          Thanks to remove.bg's clever AI, you can slash editing time – and have more fun!
        </Typography>

        <Typography variant="body1" color="text.secondary" sx={{ lineHeight: 1.7 }}>
          No matter if you want to make a background transparent (PNG), add a white background to a photo,{" "}
          <Box component="span" fontWeight="bold">
            extract or isolate the subject, or get the cutout of a photo
          </Box>{" "}
          – you can do all this and more with remove.bg, the AI background remover for professionals.
        </Typography>
      </Box>

      {/* Right Side - Image */}
      <Box sx={{ flex: 1, display: "flex", justifyContent: "center", alignItems: "center" }}>
        <Box
          component="img"
          src="/all-pages-2.png"
          alt="Illustration"
          sx={{ width: "100%", maxWidth: 400, height: "auto", borderRadius: 2 }}
        />
      </Box>
    </Box>

         <Box sx={{ mt: 12, textAlign: "center" }}>
          <Typography variant="h3" fontWeight="bold" gutterBottom>
            Just picture it
          </Typography>
          <Typography variant="h6" color="text.secondary" sx={{ mb: 4 }}>
            See how our AI removes backgrounds with perfect precision
          </Typography>

          <Box sx={{ width: "100%", bgcolor: "background.paper" }}>
            <Tabs
              value={tabValue}
              onChange={handleTabChange}
              centered
              variant={isMobile ? "fullWidth" : "standard"}
              sx={{ mb: 4 }}
            >
              {imagePairs.map((pair, index) => (
                <Tab key={index} label={pair.title} />
              ))}
            </Tabs>

            {imagePairsnew.map((pair, index) => (
              <Box
                key={index}
                role="tabpanel"
                hidden={tabValue !== index}
                id={`tabpanel-${index}`}
                aria-labelledby={`tab-${index}`}
              >
                {tabValue === index && (
                  <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
                    <Grid container spacing={4} justifyContent="center">
                      <Grid item xs={12} md={6}>
                        <Box sx={{ textAlign: "center", mb: 2 }}>
                          
                          <Box
                            component="img"
                            src={pair.before}
                            alt={`Before - ${pair.title}`}
                            sx={{
                              width: "100%",
                              maxWidth: 300,
                              borderRadius: 2,
                              boxShadow: 3,
                            }}
                          />
                          <Typography variant="h6" color="primary" gutterBottom>
                            Original
                          </Typography>
                        </Box>
                      </Grid>
                      <Grid item xs={12} md={6}>
                        <Box sx={{ textAlign: "center", mb: 2 }}>
                          
                          <Box
                            component="img"
                            src={pair.after}
                            alt={`After - ${pair.title}`}
                            sx={{
                              width: "100%",
                              maxWidth: 300,
                              borderRadius: 2,
                              boxShadow: 3,
                            }}
                          />
                          <Typography variant="h6" color="success.main" gutterBottom>
                            Transparent background
                          </Typography>
                        </Box>
                      </Grid>
                    </Grid>
                  </Box>
                )}
              </Box>
            ))}
          </Box>
        </Box>
      </Container>
      <Footer />
    </>
  );
}
