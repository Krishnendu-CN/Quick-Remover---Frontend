import React, { useState } from "react";
import {
  Box,
  Container,
  Typography,
  Tabs,
  Tab,
  Card,
  Grid,
  Button
} from "@mui/material";
import Header from "../components/Header";
import Footer from "../components/Footer";

export default function Dashboard({ user, onLogout }) {
  const [tabValue, setTabValue] = useState(0);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  return (
    <>
      <Header />
      <Box sx={{ minHeight: "80vh", bgcolor: "background.default", py: 6 }}>
        <Container maxWidth="lg">
          <Typography variant="h3" fontWeight="bold" gutterBottom>
            My Dashboard
          </Typography>
          <Typography variant="h6" color="text.secondary" gutterBottom>
            {user?.username}
          </Typography>

          <Card sx={{ mt: 4, p: 3 }}>
            <Tabs value={tabValue} onChange={handleTabChange}>
              <Tab label="Credits & Plan" />
              <Tab label="Payment & Billing" />
              <Tab label="API Keys" />
              <Tab label="Earn Credits" />
              <Tab label="Account Settings" />
            </Tabs>

            <Box sx={{ mt: 3 }}>
              {tabValue === 0 && (
                <Grid container spacing={4}>
                  <Grid item xs={12} md={3}>
                    <Box textAlign="center">
                      <Typography variant="h4" fontWeight="bold">
                        1.00
                      </Typography>
                      <Typography color="text.secondary">Total Credits</Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={12} md={3}>
                    <Box textAlign="center">
                      <Typography variant="h4" fontWeight="bold">
                        0.00
                      </Typography>
                      <Typography color="text.secondary">Subscription Credits</Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={12} md={3}>
                    <Box textAlign="center">
                      <Typography variant="h4" fontWeight="bold">
                        1.00
                      </Typography>
                      <Typography color="text.secondary">Pay as you go Credits</Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={12} md={3}>
                    <Box textAlign="center">
                      <Typography variant="h4" fontWeight="bold">
                        50 of 50
                      </Typography>
                      <Typography color="text.secondary">Free Previews via API</Typography>
                    </Box>
                  </Grid>
                </Grid>
              )}

              {tabValue === 1 && (
                <Typography>Payment & Billing content here...</Typography>
              )}

              {tabValue === 2 && <Typography>API Keys content here...</Typography>}
              {tabValue === 3 && <Typography>Earn Credits content here...</Typography>}
              {tabValue === 4 && (
                <Button variant="outlined" onClick={onLogout}>
                  Logout
                </Button>
              )}
            </Box>
          </Card>
        </Container>
      </Box>
      <Footer />
    </>
  );
}
